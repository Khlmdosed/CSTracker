/* CSTracker — standalone offline build. No server, CDN, or internet required. */
'use strict';

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const KEY = 'cstracker_offline_v4';
const STAFF = ['admin','professor','classrep','moderator'];
const ADMIN = ['admin'];

const schedule = [
  ['Tuesday','07:00','09:00','DCIT65','119','EMILIO DEL ROSARIO III'],
  ['Tuesday','09:00','11:00','COSC75','107','ARMIN ARAGONCILLO'],
  ['Tuesday','13:00','15:00','COSC75','109','ARMIN ARAGONCILLO'],
  ['Tuesday','15:00','17:00','MATH3','206','MA. CHRISTINE JOYCE RELLOSA'],
  ['Tuesday','17:00','19:00','DCIT26','107','JAMES RAPHAEL TOLEDO'],
  ['Wednesday','11:00','13:00','COSC85','207','MICHAEL MADSEN VENTURA'],
  ['Wednesday','13:00','15:00','COSC80','107','STEVEN GOHAN MATRO'],
  ['Thursday','09:00','11:00','COSC85','109','MICHAEL MADSEN VENTURA'],
  ['Thursday','11:00','13:00','COSC80','217','STEVEN GOHAN MATRO'],
  ['Thursday','15:00','17:00','DCIT26','217','JAMES RAPHAEL TOLEDO'],
  ['Friday','09:00','11:00','COSC101','107','CHRISTOPHER HERNANDEZ'],
  ['Friday','11:00','13:00','COSC101','107','CHRISTOPHER HERNANDEZ']
].map(x => ({day:x[0],start:x[1],end:x[2],code:x[3],room:x[4],professor:x[5]}));

const subjectNames = {
  COSC75:'SOFTWARE ENGINEERING II', MATH3:'LINEAR ALGEBRA', COSC80:'OPERATING SYSTEMS',
  COSC85:'NETWORKS AND COMMUNICATION', COSC101:'CS ELECTIVE 1',
  DCIT26:'APPLICATIONS DEVELOPMENT AND EMERGING TECHNOLOGIES', DCIT65:'SOCIAL AND PROFESSIONAL ISSUES'
};
const subjects = [...new Map(schedule.map(s => [s.code,{code:s.code,name:subjectNames[s.code]||s.code,professor:s.professor}])).values()];

function today(){ return new Date().toISOString().slice(0,10); }
function nowTime(){ return new Date().toTimeString().slice(0,5); }
function esc(v){ return String(v ?? '').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function uid(){ return Date.now() + Math.floor(Math.random()*1000); }
function fullName(u){ return [u?.firstName,u?.middleName,u?.lastName].filter(Boolean).join(' ') || 'User'; }
function roleLabel(u){ return u?.role==='student' && u?.subrole && u.subrole!=='student' ? u.subrole : (u?.role||'user'); }
function fmt(v){ let [h,m]=v.split(':').map(Number); const ap=h>=12?'PM':'AM'; h=h%12||12; return `${h}:${String(m).padStart(2,'0')} ${ap}`; }
function fmtDate(d){ if(!d)return '—'; const x=new Date(`${d}T00:00:00`); return x.toLocaleDateString([], {year:'numeric',month:'short',day:'numeric'}); }
function validDate(d){ return /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(new Date(`${d}T00:00:00`).getTime()); }

const seed = {
  users:[
    {id:1,studentId:'202413724',firstName:'Khalem',middleName:'Jacob',lastName:'Mendoza',campusEmail:'student@cvsu.edu.ph',guardianGmail:'guardian@gmail.com',password:'Demo1234!',role:'student',subrole:'student',isIrregular:false,enrolledSubjects:[],verified:true},
    {id:2,firstName:'Armin',lastName:'Aragoncillo',username:'professor',password:'Demo1234!',role:'professor',subrole:'professor',verified:true},
    {id:3,firstName:'System',lastName:'Administrator',username:'admin',password:'Demo1234!',role:'admin',subrole:'admin',verified:true},
    {id:4,firstName:'Class',lastName:'Representative',username:'classrep',password:'Demo1234!',role:'classrep',subrole:'classrep',verified:true},
    {id:5,firstName:'Course',lastName:'Moderator',username:'moderator',password:'Demo1234!',role:'moderator',subrole:'moderator',verified:true}
  ],
  announcements:[{id:1,title:'Welcome to CSTracker',subject:'General',body:'Your local tracker is ready. Schedule, attendance, announcements, calendar events, excuse letters, and messages are saved on this device.',date:today(),createdBy:3}],
  attendance:[], events:[], excuses:[], messages:[], notifications:[]
};

let db = loadDb();
let me = null;
let currentPage = 'dashboard';
let themeMode = safeGet('cstracker_theme') || 'auto';
let toastTimer;

function normalizeDb(x){
  const d = x && typeof x==='object' ? x : {};
  for(const k of ['users','announcements','attendance','events','excuses','messages','notifications']) if(!Array.isArray(d[k])) d[k]=[];
  d.users.forEach(u=>{
    u.enrolledSubjects = Array.isArray(u.enrolledSubjects) ? [...new Set(u.enrolledSubjects.map(String))] : [];
    u.verified = u.verified !== false;
    u.role = u.role || 'student'; u.subrole = u.subrole || u.role;
  });
  return d;
}
function safeGet(k){ try{return localStorage.getItem(k);}catch(_){return null;} }
function safeSet(k,v){ try{localStorage.setItem(k,v);return true;}catch(_){return false;} }
function loadDb(){
  try{
    const raw=safeGet(KEY);
    if(raw) return normalizeDb(JSON.parse(raw));
    const fresh=structuredClone(seed); safeSet(KEY,JSON.stringify(fresh)); return fresh;
  }catch(e){
    const fresh=structuredClone(seed); safeSet(KEY,JSON.stringify(fresh)); return fresh;
  }
}
function save(){
  const ok=safeSet(KEY,JSON.stringify(db));
  if(!ok)toast('Unable to save. Browser storage may be blocked or full.');
  return ok;
}
function toast(message){
  const t=$('#toast'); if(!t)return; t.textContent=message; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),2800);
}
function isStaff(){ return STAFF.includes(me?.role); }
function isAdmin(){ return ADMIN.includes(me?.role); }
function canPost(){ return isStaff(); }
function canManageAttendance(){ return isStaff(); }
function canReviewExcuses(){ return isStaff(); }

function autoNight(){ const h=new Date().getHours(); return h>=18 || h<5; }
function applyTheme(){
  const night=themeMode==='night' || (themeMode==='auto' && autoNight());
  document.body.classList.toggle('night',night);
  const b=$('#themeBtn'); if(b)b.textContent=themeMode==='auto'?'Auto':night?'Night':'Day';
}
function tick(){
  const c=$('#clock'); if(c)c.textContent=new Date().toLocaleString([], {weekday:'short',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'});
  if(themeMode==='auto')applyTheme();
  updateClassReminder();
}
setInterval(tick,1000);

function currentUserSubjects(){
  if(!me || !me.isIrregular) return subjects;
  return (me.enrolledSubjects||[]).map(c=>subjects.find(s=>s.code===c)).filter(Boolean);
}
function studentSubjects(u){
  if(!u?.isIrregular) return subjects;
  return (u.enrolledSubjects||[]).map(c=>subjects.find(s=>s.code===c)).filter(Boolean);
}
function attendanceRowsForStudent(id){ return db.attendance.filter(a=>a.studentId===id); }
function attendanceStats(studentId,subjectCode){
  const rows=db.attendance.filter(a=>a.studentId===studentId && a.subject===subjectCode);
  const late=rows.filter(a=>a.status==='Late').length;
  const absent=rows.filter(a=>a.status==='Absent').length;
  return {late,absent,effective:absent+Math.floor(late/3)};
}
function totalEffectiveAbsences(studentId){
  const codes=subjects.map(s=>s.code);
  return codes.reduce((sum,c)=>sum+attendanceStats(studentId,c).effective,0);
}
function warningLevel(studentId){ return Math.min(3, Math.floor(totalEffectiveAbsences(studentId)/3)); }
function notifyWarnings(studentId){
  const u=db.users.find(x=>x.id===studentId); if(!u)return;
  const level=warningLevel(studentId); if(level<1)return;
  const exists=db.notifications.some(n=>n.studentId===studentId && n.level===level && n.type==='attendance-warning');
  if(!exists){
    db.notifications.push({id:uid(),studentId,level,type:'attendance-warning',date:today(),message:`Warning ${level}: ${fullName(u)} has reached ${level*3} effective absences.`});
    save();
  }
}

function upcomingClassesForUser(){
  const allowed=new Set(currentUserSubjects().map(s=>s.code));
  return schedule.filter(s=>allowed.has(s.code));
}
function nextClass(){
  const now=new Date(); const day=now.toLocaleDateString('en-US',{weekday:'long'});
  const mins=now.getHours()*60+now.getMinutes();
  const todayRows=upcomingClassesForUser().filter(s=>s.day===day).sort((a,b)=>a.start.localeCompare(b.start));
  for(const s of todayRows){ const sm=+s.start.slice(0,2)*60 + +s.start.slice(3); if(sm>=mins)return s; }
  const order=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']; const di=order.indexOf(day);
  for(let i=1;i<=7;i++){ const d=order[(di+i)%7]; const r=upcomingClassesForUser().filter(s=>s.day===d).sort((a,b)=>a.start.localeCompare(b.start)); if(r[0])return r[0]; }
  return null;
}
function minutesUntil(s){
  if(!s)return null; const now=new Date(); const target=new Date(now); const dayNames=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  let delta=(dayNames.indexOf(s.day)-now.getDay()+7)%7;
  const [h,m]=s.start.split(':').map(Number); target.setDate(now.getDate()+delta); target.setHours(h,m,0,0); if(target<=now)target.setDate(target.getDate()+7); return Math.round((target-now)/60000);
}
function updateClassReminder(){
  const r=$('#classReminder'); if(!r || !me || me.role!=='student')return;
  const n=nextClass(), mins=minutesUntil(n);
  if(n && mins!==null && mins<=15){ r.classList.remove('hidden'); r.textContent=`Class reminder: ${n.code} starts in ${Math.max(0,mins)} min • Room ${n.room}`; }
  else r.classList.add('hidden');
}

// Auth
$$('.auth-tabs button').forEach(b=>b.addEventListener('click',()=>{
  $$('.auth-tabs button').forEach(x=>x.classList.remove('active')); b.classList.add('active');
  $('#loginForm').classList.toggle('hidden',b.dataset.auth!=='login'); $('#registerForm').classList.toggle('hidden',b.dataset.auth!=='register');
  $('#authError').textContent='';
}));
$('#irregular').addEventListener('change',e=>$('#irregSubjects').classList.toggle('hidden',e.target.value!=='1'));

function login(identifier,password){
  const id=identifier.trim().toLowerCase();
  const u=db.users.find(x=>(x.campusEmail||'').toLowerCase()===id || (x.username||'').toLowerCase()===id);
  if(!u || u.password!==password) throw Error('Invalid email/username or password.');
  if(u.verified===false) throw Error('This account is awaiting verification.');
  return u;
}
$('#loginForm').addEventListener('submit',e=>{
  e.preventDefault();
  try{ me=login($('#identifier').value,$('#password').value); sessionStorage.setItem('cstracker_session',String(me.id)); showApp(); }
  catch(err){ $('#authError').textContent=err.message; toast(err.message); }
});
$('#registerForm').addEventListener('submit',e=>{
  e.preventDefault(); const o=Object.fromEntries(new FormData(e.target));
  const studentId=o.studentId.trim(), email=o.campusEmail.trim().toLowerCase(), guardian=o.guardianGmail.trim().toLowerCase();
  if(!/^\d{6,15}$/.test(studentId))return toast('Student ID must contain 6–15 digits.');
  if(!/^[^@\s]+@cvsu\.edu\.ph$/i.test(email))return toast('Use a valid @cvsu.edu.ph campus email.');
  if(!/^[^@\s]+@gmail\.com$/i.test(guardian))return toast('Guardian email must be a Gmail address.');
  if(!o.password || o.password.length<8)return toast('Password must be at least 8 characters.');
  if(db.users.some(u=>(u.campusEmail||'').toLowerCase()===email))return toast('Campus email already exists.');
  if(db.users.some(u=>u.studentId===studentId))return toast('Student ID already exists.');
  const enrolled=[...new Set((o.enrolledSubjects||'').split(',').map(x=>x.trim().toUpperCase()).filter(Boolean))];
  const invalid=enrolled.filter(c=>!subjects.some(s=>s.code===c));
  if(o.isIrregular==='1' && !enrolled.length)return toast('Select at least one subject for an irregular student.');
  if(invalid.length)return toast(`Unknown subject code: ${invalid.join(', ')}`);
  const u={id:uid(),studentId,firstName:o.firstName.trim(),middleName:o.middleName.trim(),lastName:o.lastName.trim(),campusEmail:email,guardianGmail:guardian,password:o.password,role:'student',subrole:'student',isIrregular:o.isIrregular==='1',enrolledSubjects:o.isIrregular==='1'?enrolled:[],verified:true};
  db.users.push(u); if(!save())return;
  e.target.reset(); $('#irregSubjects').classList.add('hidden'); $$('.auth-tabs button')[0].click();
  toast('Offline account created. Email confirmation is simulated because this build has no mail server.');
});
$$('[data-demo]').forEach(b=>b.addEventListener('click',()=>{ const u=db.users.find(x=>x.role===b.dataset.demo); if(u){me=u;sessionStorage.setItem('cstracker_session',String(u.id));showApp();} }));
$('#logout').addEventListener('click',()=>{me=null;sessionStorage.removeItem('cstracker_session');location.reload();});
$('#themeBtn').addEventListener('click',()=>{themeMode=themeMode==='auto'?'night':themeMode==='night'?'day':'auto';safeSet('cstracker_theme',themeMode);applyTheme();});

function showApp(){
  $('#authView').classList.add('hidden'); $('#appView').classList.remove('hidden');
  $('#userName').textContent=fullName(me); $('#userRole').textContent=roleLabel(me).replaceAll('_',' ');
  $('#avatar').textContent=((me.firstName||'U')[0]+(me.lastName||'S')[0]).toUpperCase();
  $('#classReminder').classList.add('hidden');
  $$('.staff-only').forEach(b=>b.classList.toggle('hidden',!isStaff()));
  $$('.student-only').forEach(b=>b.classList.toggle('hidden',me.role!=='student'));
  render('dashboard'); applyTheme(); tick();
}
function head(title,subtitle=''){ return `<div class="page-head"><div><h1>${esc(title)}</h1><p class="muted">${esc(subtitle)}</p></div></div>`; }
function navTo(page){
  const b=$(`.sidebar nav button[data-page="${page}"]`); if(b)b.click();
}
$('#nav').addEventListener('click',e=>{
  const b=e.target.closest('button[data-page]'); if(!b)return;
  if(b.classList.contains('staff-only') && !isStaff())return;
  $$('.sidebar nav button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); currentPage=b.dataset.page; render(currentPage);
});

function dashboard(){
  if(me.role==='student'){
    const rows=attendanceRowsForStudent(me.id), late=rows.filter(a=>a.status==='Late').length, absent=rows.filter(a=>a.status==='Absent').length, effective=totalEffectiveAbsences(me.id), warn=warningLevel(me.id), next=nextClass();
    $('#main').innerHTML=head(`Good day, ${me.firstName||'Student'} 👋`,`CSTracker overview • ${new Date().toLocaleDateString()} • saved locally`)+
    `<div class="cards">
      <div class="card stat"><span class="muted">Effective absences</span><b>${effective}</b><small class="${effective>=3?'danger':'success'}">${effective>=3?'Warning threshold reached':'Within threshold'}</small></div>
      <div class="card stat"><span class="muted">Lates</span><b>${late}</b><small>3 lates = 1 absence per subject</small></div>
      <div class="card stat"><span class="muted">Subjects</span><b>${currentUserSubjects().length}</b><small>${me.isIrregular?'Irregular enrollment':'Regular enrollment'}</small></div>
      <div class="card stat"><span class="muted">Warning level</span><b>${warn || 'None'}</b><small>${warn?'Guardian notification is required at this level.':'No warning yet.'}</small></div>
    </div>
    <div class="grid2">
      <div class="card"><div class="section-title"><h3>Next class</h3><button class="ghost" data-go="schedule">View schedule</button></div>${next?`<div class="next-class"><b>${esc(next.code)} — ${esc(subjectNames[next.code])}</b><span>${esc(next.day)} ${fmt(next.start)}–${fmt(next.end)} • Room ${esc(next.room)}</span><small>${esc(next.professor)}</small></div>`:'<p class="muted">No scheduled classes.</p>'}</div>
      <div class="card"><div class="section-title"><h3>Latest announcements</h3><button class="ghost" data-go="announcements">View all</button></div>${db.announcements.slice(-3).reverse().map(a=>`<div class="notice"><b>${esc(a.title)}</b><span class="muted">${esc(a.subject)} · ${esc(a.date)}</span></div>`).join('')||'<p class="muted">No announcements.</p>'}</div>
    </div>`;
  } else {
    const students=db.users.filter(u=>u.role==='student'), totalAbs=students.reduce((n,u)=>n+totalEffectiveAbsences(u.id),0), pending=db.excuses.filter(x=>x.status==='Pending').length;
    $('#main').innerHTML=head(`Welcome, ${me.firstName||'Staff'} 👋`,`CSTracker staff dashboard • local administration`)+
    `<div class="cards"><div class="card stat"><span class="muted">Students</span><b>${students.length}</b><small>Registered local accounts</small></div><div class="card stat"><span class="muted">Attendance records</span><b>${db.attendance.length}</b><small>All subjects</small></div><div class="card stat"><span class="muted">Pending excuses</span><b>${pending}</b><small>Awaiting review</small></div><div class="card stat"><span class="muted">Effective absences</span><b>${totalAbs}</b><small>Across all students</small></div></div>
    <div class="grid2"><div class="card"><div class="section-title"><h3>Quick actions</h3></div><div class="action-grid"><button class="action" data-go="attendance">✓ Attendance</button><button class="action" data-go="announcements">▰ Announcement</button><button class="action" data-go="calendar">◷ Calendar event</button><button class="action" data-go="inbox">✉ Inbox</button></div></div><div class="card"><h3>Recent activity</h3>${db.attendance.slice(-5).reverse().map(a=>{const u=db.users.find(x=>x.id===a.studentId);return `<div class="notice"><b>${esc(u?.studentId||'Unknown')} · ${esc(a.subject)}</b><span class="muted">${esc(a.date)} · ${esc(a.status)}</span></div>`}).join('')||'<p class="muted">No attendance activity.</p>'}</div></div>`;
  }
  $$('[data-go]').forEach(b=>b.addEventListener('click',()=>navTo(b.dataset.go)));
}

function schedulePage(){
  const days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']; const hours=Array.from({length:13},(_,i)=>i+7);
  const allowed=new Set(currentUserSubjects().map(s=>s.code));
  $('#main').innerHTML=head('Schedule','Hover or select a class for professor, room, and course details.')+`<div class="schedule-wrap"><div class="schedule" id="sched"><div class="cell head"></div>${days.map(d=>`<div class="cell head">${d}</div>`).join('')}${hours.map(h=>`<div class="cell time">${fmt(String(h).padStart(2,'0')+':00')}</div>${days.map(()=>'<div class="cell"></div>').join('')}`).join('')}</div></div>`;
  const grid=$('#sched'), start=7, cellH=66;
  schedule.forEach(s=>{
    if(me.role==='student' && !allowed.has(s.code))return;
    const col=days.indexOf(s.day); if(col<0)return;
    const st=+s.start.slice(0,2)+ +s.start.slice(3)/60, en=+s.end.slice(0,2)+ +s.end.slice(3)/60;
    const el=document.createElement('button'); el.type='button'; el.className='slot';
    el.style.cssText=`left:calc(90px + (100% - 90px)/6 * ${col} + 4px);top:${48+(st-start)*cellH}px;width:calc((100% - 90px)/6 - 8px);height:${Math.max(54,(en-st)*cellH-8)}px`;
    el.innerHTML=`<small>${fmt(s.start)} – ${fmt(s.end)}</small><b>${esc(s.code)}</b><span>${esc(subjectNames[s.code])}<br>Room ${esc(s.room)}<br>${esc(s.professor)}</span>`;
    el.title=`${s.code} — ${s.professor} — Room ${s.room}`;
    el.addEventListener('click',()=>toast(`${s.code} • ${s.professor} • Room ${s.room}`)); grid.appendChild(el);
  });
  grid.style.height=`${48+(19-7)*cellH+10}px`;
  $('#main').insertAdjacentHTML('beforeend',`<div class="card schedule-list"><h3>Course list</h3><div class="course-grid">${currentUserSubjects().map(s=>`<div class="course"><b>${esc(s.code)}</b><span>${esc(s.name)}</span><small>${esc(s.professor)}</small></div>`).join('')}</div></div>`);
}

function calendarPage(){
  const now=new Date(), y=now.getFullYear(), m=now.getMonth(), first=new Date(y,m,1).getDay(), daysInMonth=new Date(y,m+1,0).getDate(); let cells='';
  for(let i=0;i<first;i++)cells+='<div class="day empty"></div>';
  for(let d=1;d<=daysInMonth;d++){
    const ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`, ev=db.events.filter(e=>e.date===ds);
    cells+=`<button type="button" class="day day-button" data-date="${ds}"><strong>${d}</strong>${ev.slice(0,3).map(e=>`<span class="event ${String(e.type).toLowerCase()}">${esc(e.type)}: ${esc(e.title)}</span>`).join('')}${ev.length>3?`<span class="event">+${ev.length-3} more</span>`:''}</button>`;
  }
  const canEdit=isStaff();
  $('#main').innerHTML=head('Calendar','Holidays, exams, quizzes, class notes, and events.')+`<div class="card calendar-box"><div class="calendar-title"><h2>${now.toLocaleString([],{month:'long',year:'numeric'})}</h2><span class="muted">Click a day for details</span></div><div class="calendar">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(x=>`<div class="day head-day"><strong>${x}</strong></div>`).join('')}${cells}</div></div><div id="dayDetails" class="card detail-card"><p class="muted">Select a day to see all events and scheduled classes.</p></div>${canEdit?`<div class="card form-card"><h3>Add calendar event</h3><form id="eventForm" class="form-grid"><label>Date<input type="date" name="date" value="${today()}" required></label><label>Type<select name="type"><option>Holiday</option><option>Exam</option><option>Quiz</option><option>Class</option><option>Other</option></select></label><label>Title<input name="title" maxlength="100" required></label><label>Description<input name="description" maxlength="240"></label><button class="primary" type="submit">Save event</button></form></div>`:''}`;
  $$('.day-button').forEach(b=>b.addEventListener('click',()=>showDayDetails(b.dataset.date)));
  const f=$('#eventForm'); if(f)f.addEventListener('submit',e=>{e.preventDefault();const o=Object.fromEntries(new FormData(f));if(!validDate(o.date))return toast('Choose a valid date.');db.events.push({...o,id:uid(),createdBy:me.id});save();calendarPage();toast('Calendar event saved.');});
}
function showDayDetails(ds){
  const d=new Date(`${ds}T00:00:00`), day=d.toLocaleDateString('en-US',{weekday:'long'}), ev=db.events.filter(e=>e.date===ds), classes=schedule.filter(s=>s.day===day && (me.role!=='student'||currentUserSubjects().some(x=>x.code===s.code)));
  const box=$('#dayDetails'); if(!box)return;
  box.innerHTML=`<div class="section-title"><div><h3>${esc(day)}, ${esc(fmtDate(ds))}</h3><p class="muted">${classes.length} scheduled class${classes.length===1?'':'es'} • ${ev.length} event${ev.length===1?'':'s'}</p></div></div><div class="detail-grid"><div><h4>Classes</h4>${classes.map(s=>`<div class="notice"><b>${esc(s.code)} — ${esc(subjectNames[s.code])}</b><span class="muted">${fmt(s.start)}–${fmt(s.end)} • Room ${esc(s.room)} • ${esc(s.professor)}</span></div>`).join('')||'<p class="muted">No scheduled classes.</p>'}</div><div><h4>Events</h4>${ev.map(e=>`<div class="notice"><b>${esc(e.type)}: ${esc(e.title)}</b><span class="muted">${esc(e.description||'No description')}</span>${isStaff()?`<button class="danger-btn delete-event" data-id="${e.id}">Delete</button>`:''}</div>`).join('')||'<p class="muted">No calendar events.</p>'}</div></div>`;
  $$('.delete-event',box).forEach(b=>b.addEventListener('click',()=>{if(!isStaff())return;db.events=db.events.filter(e=>String(e.id)!==String(b.dataset.id));save();calendarPage();showDayDetails(ds);toast('Event deleted.');}));
}

function announcementsPage(){
  const can=canPost();
  $('#main').innerHTML=head('Announcements','Tasks, assignments, lectures, and notices.')+`<div class="card">${db.announcements.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).map(a=>`<article class="announcement"><span class="tag">${esc(a.subject)}</span><h3>${esc(a.title)}</h3><p>${esc(a.body)}</p><small class="muted">${esc(fmtDate(a.date))}</small>${can?`<button class="danger-btn delete-ann" data-id="${a.id}">Delete</button>`:''}</article>`).join('')||'<p class="muted">No announcements.</p>'}</div>${can?`<div class="card form-card"><h3>Post announcement</h3><form id="annForm"><div class="form-grid"><label>Subject<input name="subject" maxlength="80" required></label><label>Title<input name="title" maxlength="120" required></label></div><label>Message<textarea name="body" rows="5" maxlength="2000" required></textarea><button class="primary" type="submit">Publish</button></form></div>`:''}`;
  const f=$('#annForm'); if(f)f.addEventListener('submit',e=>{e.preventDefault();const o=Object.fromEntries(new FormData(f));db.announcements.push({...o,id:uid(),date:today(),createdBy:me.id});save();announcementsPage();toast('Announcement published.');});
  $$('.delete-ann').forEach(b=>b.addEventListener('click',()=>{db.announcements=db.announcements.filter(a=>String(a.id)!==String(b.dataset.id));save();announcementsPage();toast('Announcement deleted.');}));
}

function attendancePage(){
  if(me.role==='student'){
    const rows=attendanceRowsForStudent(me.id).slice().sort((a,b)=>`${b.date}${b.subject}`.localeCompare(`${a.date}${a.subject}`));
    $('#main').innerHTML=head('Attendance','Your attendance records. Lates are converted to one effective absence after every 3 lates within the same subject.')+`<div class="cards"><div class="card stat"><span class="muted">Present</span><b>${rows.filter(a=>a.status==='Present').length}</b></div><div class="card stat"><span class="muted">Late</span><b>${rows.filter(a=>a.status==='Late').length}</b></div><div class="card stat"><span class="muted">Absent</span><b>${rows.filter(a=>a.status==='Absent').length}</b></div><div class="card stat"><span class="muted">Effective</span><b>${totalEffectiveAbsences(me.id)}</b></div></div><div class="card"><div class="table-scroll"><table><thead><tr><th>Subject</th><th>Date</th><th>Status</th><th>Verification</th></tr></thead><tbody>${rows.map(a=>`<tr><td><b>${esc(a.subject)}</b><br><span class="muted">${esc(subjectNames[a.subject]||'')}</span></td><td>${esc(fmtDate(a.date))}</td><td><span class="status ${esc(a.status)}">${esc(a.status)}</span></td><td>${a.verified?'Verified':'Pending'}${a.verifiedBy?`<br><small class="muted">Staff ID ${esc(a.verifiedBy)}</small>`:''}</td></tr>`).join('')||'<tr><td colspan="4" class="muted">No attendance records.</td></tr>'}</tbody></table></div></div>`;
    return;
  }
  const students=db.users.filter(u=>u.role==='student').sort((a,b)=>String(a.studentId).localeCompare(String(b.studentId)));
  const can=canManageAttendance();
  $('#main').innerHTML=head('Attendance','Staff can verify attendance, review each student, and record status. Each student/subject/date can only have one record.')+
  `<div class="card"><div class="toolbar"><input id="attendanceSearch" placeholder="Search student ID or name"><select id="attendanceFilter"><option value="all">All students</option><option value="warning">Warning level ≥ 1</option></select></div><div class="table-scroll"><table><thead><tr><th>Student</th><th>Subjects</th><th>Effective absences</th><th>Warning</th><th>Action</th></tr></thead><tbody id="attendanceStudents">${students.map(u=>attendanceStudentRow(u)).join('')||'<tr><td colspan="5" class="muted">No student accounts.</td></tr>'}</tbody></table></div></div>`+
  (can?`<div class="card form-card"><h3>Manual / QR verification</h3><p class="muted">Offline mode cannot access a camera scanner. Use the student's permanent QR identity card as the second-step reference, then enter the Student ID here to verify attendance.</p><form id="attForm" class="form-grid"><label>Student ID<input name="studentId" id="attStudentId" required></label><label>Subject<select name="subject">${subjects.map(s=>`<option value="${esc(s.code)}">${esc(s.code)} — ${esc(s.name)}</option>`).join('')}</select></label><label>Date<input type="date" name="date" value="${today()}" required></label><label>Status<select name="status"><option>Present</option><option>Late</option><option>Absent</option></select></label><label>Verification<input name="verification" placeholder="Optional verification note"></label><button class="primary" type="submit">Accept Attendance</button></form></div>`:'');
  $('#attendanceSearch').addEventListener('input',filterAttendance); $('#attendanceFilter').addEventListener('change',filterAttendance); $$('.view-student').forEach(b=>b.addEventListener('click',()=>studentDetail(Number(b.dataset.id))));
  const f=$('#attForm'); if(f)f.addEventListener('submit',e=>{e.preventDefault();const o=Object.fromEntries(new FormData(f)),u=db.users.find(x=>x.role==='student'&&x.studentId===o.studentId.trim());if(!u)return toast('Student ID not found.');if(u.isIrregular&&!u.enrolledSubjects.includes(o.subject))return toast('This irregular student is not enrolled in that subject.');if(!validDate(o.date))return toast('Choose a valid date.');if(db.attendance.some(a=>a.studentId===u.id&&a.subject===o.subject&&a.date===o.date))return toast('Attendance already exists for this student, subject, and date.');db.attendance.push({id:uid(),studentId:u.id,subject:o.subject,date:o.date,status:o.status,verified:true,verifiedBy:me.id,verification:o.verification.trim()});notifyWarnings(u.id);save();toast('Attendance accepted and verified.');attendancePage();});
}
function attendanceStudentRow(u){const abs=totalEffectiveAbsences(u.id), warn=warningLevel(u.id);return `<tr data-student="${esc(`${u.studentId} ${fullName(u)}`.toLowerCase())}" data-warning="${warn}"><td><b>${esc(u.studentId)}</b><br>${esc(fullName(u))}<br><small class="muted">${esc(u.campusEmail||'')}</small></td><td>${studentSubjects(u).length}</td><td>${abs}</td><td>${warn?`<span class="status Absent">Warning ${warn}</span>`:'<span class="status Present">None</span>'}</td><td><button class="ghost view-student" data-id="${u.id}">View</button></td></tr>`;}
function filterAttendance(){const q=$('#attendanceSearch').value.toLowerCase().trim(), f=$('#attendanceFilter').value; $$('#attendanceStudents tr').forEach(r=>{const text=r.dataset.student||'', warn=Number(r.dataset.warning||0);r.classList.toggle('hidden',!!q&&!text.includes(q) || f==='warning'&&warn<1);});$$('.view-student').forEach(b=>b.addEventListener('click',()=>studentDetail(Number(b.dataset.id))));}
function studentDetail(id){
  const u=db.users.find(x=>x.id===id); if(!u)return; const rows=attendanceRowsForStudent(id); const stats=studentSubjects(u).map(s=>({...s,...attendanceStats(id,s.code)}));
  $('#main').innerHTML=head(`Student ${u.studentId}`,'Attendance and enrollment details.')+`<div class="grid2"><div class="card"><h3>Student information</h3><dl class="info"><dt>Name</dt><dd>${esc(fullName(u))}</dd><dt>Campus email</dt><dd>${esc(u.campusEmail||'—')}</dd><dt>Guardian Gmail</dt><dd>${esc(u.guardianGmail||'—')}</dd><dt>Type</dt><dd>${u.isIrregular?'Irregular':'Regular'}</dd><dt>Warning level</dt><dd>${warningLevel(u.id)||'None'}</dd></dl></div><div class="card"><h3>Subject attendance</h3>${stats.map(s=>`<div class="stat-line"><span><b>${esc(s.code)}</b><small>${esc(s.name)}</small></span><span>Present ${rows.filter(a=>a.subject===s.code&&a.status==='Present').length} · Late ${s.late} · Absent ${s.absent}<br><b>Effective: ${s.effective}</b></span></div>`).join('')}</div></div><div class="card"><div class="section-title"><h3>Attendance records</h3><button class="ghost" data-go="attendance">Back</button></div><div class="table-scroll"><table><thead><tr><th>Date</th><th>Subject</th><th>Status</th><th>Verified by</th></tr></thead><tbody>${rows.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(a=>`<tr><td>${esc(fmtDate(a.date))}</td><td>${esc(a.subject)}</td><td><span class="status ${esc(a.status)}">${esc(a.status)}</span></td><td>${esc(a.verifiedBy||'—')}</td></tr>`).join('')||'<tr><td colspan="4" class="muted">No records.</td></tr>'}</tbody></table></div></div>`;
  $('[data-go]')?.addEventListener('click',()=>navTo('attendance'));
}

function qrSvg(seedText){
  // Deliberately labeled QR-style: this is not a standards-compliant QR encoder.
  const n=25; let hash=2166136261; for(const c of seedText)hash=Math.imul(hash^c.charCodeAt(0),16777619)>>>0;
  const on=(x,y)=>{let z=(Math.imul(x+11,2654435761)^Math.imul(y+7,1597334677)^hash)>>>0;return z%9<4;};
  let s=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${n}" role="img" aria-label="Student identity QR-style graphic"><rect width="25" height="25" fill="white"/>`;
  for(let y=0;y<n;y++)for(let x=0;x<n;x++){const f=(ox,oy)=>x>=ox&&x<ox+7&&y>=oy&&y<oy+7;if(f(0,0)||f(18,0)||f(0,18)){const ox=x>=18?18:0,oy=y>=18?18:0,dx=x-ox,dy=y-oy;if(dx===0||dx===6||dy===0||dy===6||(dx>=2&&dx<=4&&dy>=2&&dy<=4))s+=`<rect x="${x}" y="${y}" width="1" height="1" fill="black"/>`;}else if(on(x,y))s+=`<rect x="${x}" y="${y}" width="1" height="1" fill="black"/>`;}
  return s+'</svg>';
}
function qrPage(){
  const isStudent=me.role==='student';
  if(isStudent){
    const payload=`CSTracker|StudentID:${me.studentId}|Email:${me.campusEmail}`;
    $('#main').innerHTML=head('My Permanent QR Code','Your permanent identity card. Present this to authorized staff for attendance verification.')+`<div class="card qr-card"><div class="qr-wrap">${qrSvg(payload)}</div><h2>${esc(me.studentId)}</h2><p>${esc(fullName(me))}</p><p class="muted">${esc(me.campusEmail)}</p><div class="payload-box"><b>Identity reference</b><code>${esc(payload)}</code></div><button class="primary" type="button" id="printQr">Print QR card</button><p class="warning-note">This standalone build uses a QR-style identity graphic, not a standards-compliant scannable QR code. A real scanner requires a bundled QR encoder/decoder or the server build.</p></div>`;
    $('#printQr').addEventListener('click',()=>window.print());
  } else {
    $('#main').innerHTML=head('QR Attendance Tracker','Authorized staff verification workspace.')+`<div class="grid2"><div class="card"><h3>Verification workflow</h3><ol class="steps"><li>Student displays their permanent identity card.</li><li>Staff confirms the Student ID.</li><li>Staff records Present, Late, or Absent.</li><li>The record is locked against duplicates for that student, subject, and date.</li></ol><button class="primary" data-go="attendance">Open attendance verification</button></div><div class="card"><h3>Access</h3><p class="muted">Students can only see their own identity card. Staff roles can access the verification tracker.</p><div class="access-list">${STAFF.map(r=>`<span class="tag">${esc(r)}</span>`).join('')}</div></div></div>`;
    $('[data-go]')?.addEventListener('click',()=>navTo('attendance'));
  }
}

function inboxPage(){
  const isStaffUser=isStaff();
  const visible=isStaffUser ? db.messages : db.messages.filter(m=>m.to===me.id || m.to==='all');
  $('#main').innerHTML=head('Inbox','Local messages between students and authorized staff.')+
  `<div class="card"><div class="section-title"><h3>Messages</h3><span class="muted">${visible.length} message${visible.length===1?'':'s'}</span></div>${visible.slice().reverse().map(m=>`<div class="message"><div><b>${esc(m.fromName||'CSTracker')}</b><span class="tag">${esc(m.to==='all'?'All students':'Private')}</span></div><p>${esc(m.body)}</p><small class="muted">${esc(fmtDate(m.date))}</small></div>`).join('')||'<p class="muted">No messages yet.</p>'}</div>`+
  (isStaffUser?`<div class="card form-card"><h3>Send message</h3><form id="msgForm"><label>Recipient<select name="recipient"><option value="all">All students</option>${db.users.filter(u=>u.role==='student').map(u=>`<option value="${u.id}">${esc(u.studentId)} — ${esc(fullName(u))}</option>`).join('')}</select></label><label>Message<textarea name="body" rows="5" maxlength="2000" required></textarea></label><button class="primary" type="submit">Send</button></form></div>`:'');
  const f=$('#msgForm');if(f)f.addEventListener('submit',e=>{e.preventDefault();const o=Object.fromEntries(new FormData(f));db.messages.push({id:uid(),from:me.id,fromName:fullName(me),to:o.recipient==='all'?'all':Number(o.recipient),body:o.body.trim(),date:today()});save();inboxPage();toast('Message sent locally.');});
}

function excusePage(){
  if(!isStaff()){
    const mine=db.excuses.filter(x=>x.studentId===me.id);
    $('#main').innerHTML=head('Excuse Letter','Submit an excuse letter and track its status.')+`<div class="card"><form id="exForm"><label>Subject<select name="subject">${currentUserSubjects().map(s=>`<option value="${esc(s.code)}">${esc(s.code)} — ${esc(s.name)}</option>`).join('')}</select></label><label>Date of absence<input type="date" name="absenceDate" value="${today()}" required></label><label>Reason<textarea name="reason" rows="6" maxlength="2000" required></textarea></label><button class="primary" type="submit">Submit excuse letter</button></form></div><div class="card"><h3>My submissions</h3>${mine.slice().reverse().map(x=>`<div class="notice"><b>${esc(x.subject)} · ${esc(fmtDate(x.absenceDate))}</b><span class="muted">${esc(x.reason)}</span><span class="status ${x.status==='Approved'?'Present':x.status==='Rejected'?'Absent':'Late'}">${esc(x.status)}</span></div>`).join('')||'<p class="muted">No submissions.</p>'}</div>`;
    const f=$('#exForm');f.addEventListener('submit',e=>{e.preventDefault();const o=Object.fromEntries(new FormData(f));if(!validDate(o.absenceDate))return toast('Choose a valid date.');db.excuses.push({id:uid(),studentId:me.id,subject:o.subject,absenceDate:o.absenceDate,reason:o.reason.trim(),status:'Pending',date:today()});save();excusePage();toast('Excuse letter submitted locally.');});
    return;
  }
  $('#main').innerHTML=head('Excuse Letters','Authorized staff can review and update submissions.')+`<div class="card"><div class="toolbar"><select id="excuseFilter"><option value="all">All</option><option>Pending</option><option>Approved</option><option>Rejected</option></select></div><div class="table-scroll"><table><thead><tr><th>Student</th><th>Subject/date</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead><tbody id="excuseRows">${db.excuses.slice().reverse().map(x=>{const u=db.users.find(q=>q.id===x.studentId);return `<tr data-status="${esc(x.status)}"><td>${esc(u?.studentId||'Unknown')}<br>${esc(fullName(u)||'')}</td><td>${esc(x.subject)}<br>${esc(fmtDate(x.absenceDate))}</td><td>${esc(x.reason)}</td><td><span class="status ${x.status==='Approved'?'Present':x.status==='Rejected'?'Absent':'Late'}">${esc(x.status)}</span></td><td>${x.status==='Pending'?`<button class="ghost approve" data-id="${x.id}">Approve</button> <button class="danger-btn reject" data-id="${x.id}">Reject</button>`:'—'}</td></tr>`;}).join('')||'<tr><td colspan="5" class="muted">No excuse letters.</td></tr>'}</tbody></table></div></div>`;
  $('#excuseFilter').addEventListener('change',()=>{$$('#excuseRows tr').forEach(r=>r.classList.toggle('hidden',$('#excuseFilter').value!=='all'&&r.dataset.status!==$('#excuseFilter').value));});
  $$('.approve').forEach(b=>b.addEventListener('click',()=>updateExcuse(b.dataset.id,'Approved'))); $$('.reject').forEach(b=>b.addEventListener('click',()=>updateExcuse(b.dataset.id,'Rejected')));
}
function updateExcuse(id,status){const x=db.excuses.find(e=>String(e.id)===String(id));if(!x)return;x.status=status;x.reviewedBy=me.id;x.reviewedDate=today();save();excusePage();toast(`Excuse letter ${status.toLowerCase()}.`);}

function adminPage(){
  if(!isStaff())return dashboard();
  const canAdmin=isAdmin();
  $('#main').innerHTML=head('Administration',canAdmin?'Full local administration and data controls.':'Staff administration and overview.')+
  `<div class="cards"><div class="card stat"><span class="muted">Accounts</span><b>${db.users.length}</b></div><div class="card stat"><span class="muted">Attendance</span><b>${db.attendance.length}</b></div><div class="card stat"><span class="muted">Announcements</span><b>${db.announcements.length}</b></div><div class="card stat"><span class="muted">Events</span><b>${db.events.length}</b></div></div>
  <div class="card"><div class="section-title"><h3>User accounts</h3><input id="userSearch" class="compact" placeholder="Search users"></div><div class="table-scroll"><table><thead><tr><th>ID</th><th>Name</th><th>Contact</th><th>Role</th><th>Enrollment</th><th>Action</th></tr></thead><tbody id="userRows">${db.users.map(u=>userRow(u,canAdmin)).join('')}</tbody></table></div></div>
  ${canAdmin?`<div class="card form-card"><h3>Create staff account</h3><form id="staffForm" class="form-grid"><label>First name<input name="firstName" required></label><label>Last name<input name="lastName" required></label><label>Username<input name="username" required></label><label>Password<input name="password" minlength="8" required></label><label>Role<select name="role"><option>professor</option><option>classrep</option><option>moderator</option></select></label><button class="primary" type="submit">Create staff</button></form></div><div class="card danger-zone"><h3>Local data controls</h3><p class="muted">Export creates a JSON backup. Import replaces local CSTracker data after confirmation.</p><div class="button-row"><button id="exportData" class="ghost">Export backup</button><button id="importData" class="ghost">Import backup</button><button id="resetData" class="danger-btn">Reset local data</button></div><input type="file" id="importFile" accept="application/json" class="hidden"></div>`:''}`;
  $('#userSearch').addEventListener('input',()=>{$$('#userRows tr').forEach(r=>r.classList.toggle('hidden',!r.dataset.search.includes($('#userSearch').value.toLowerCase().trim())));});
  $$('.edit-user').forEach(b=>b.addEventListener('click',()=>editUser(Number(b.dataset.id)))); $$('.delete-user').forEach(b=>b.addEventListener('click',()=>deleteUser(Number(b.dataset.id))));
  const sf=$('#staffForm');if(sf)sf.addEventListener('submit',e=>{e.preventDefault();const o=Object.fromEntries(new FormData(sf));if(db.users.some(u=>(u.username||'').toLowerCase()===o.username.toLowerCase()))return toast('Username already exists.');db.users.push({id:uid(),firstName:o.firstName.trim(),lastName:o.lastName.trim(),username:o.username.trim(),password:o.password,role:o.role,subrole:o.role,verified:true});save();adminPage();toast('Staff account created.');});
  $('#exportData')?.addEventListener('click',exportData);$('#importData')?.addEventListener('click',()=>$('#importFile').click());$('#importFile')?.addEventListener('change',importData);$('#resetData')?.addEventListener('click',resetData);
}
function userRow(u,canAdmin){return `<tr data-search="${esc(`${u.studentId||''} ${fullName(u)} ${u.campusEmail||''} ${u.username||''} ${u.role}`.toLowerCase())}"><td>${esc(u.studentId||'—')}</td><td>${esc(fullName(u))}</td><td>${esc(u.campusEmail||u.username||'—')}</td><td><span class="tag">${esc(roleLabel(u))}</span></td><td>${u.role==='student'?(u.isIrregular?'Irregular':'Regular'):'Staff'}</td><td>${canAdmin?`<button class="ghost edit-user" data-id="${u.id}">Edit</button> ${u.id!==me.id?`<button class="danger-btn delete-user" data-id="${u.id}">Delete</button>`:''}`:'View only'}</td></tr>`;}
function editUser(id){
  const u=db.users.find(x=>x.id===id);if(!u)return;
  const role=prompt('Role (student, professor, admin, classrep, moderator):',u.role); if(role===null)return;
  const r=role.trim().toLowerCase();if(!STAFF.includes(r)&&r!=='student')return toast('Invalid role.');
  u.role=r;u.subrole=r;
  if(r==='student'){u.isIrregular=confirm('Should this student be irregular?');if(u.isIrregular){const codes=prompt('Subject codes, comma separated:',(u.enrolledSubjects||[]).join(', '));if(codes!==null)u.enrolledSubjects=[...new Set(codes.split(',').map(x=>x.trim().toUpperCase()).filter(c=>subjects.some(s=>s.code===c)))];}}
  save(); if(me.id===id){me=u;showApp();} else adminPage();toast('User updated.');
}
function deleteUser(id){if(!isAdmin()||id===me.id)return;if(!confirm('Delete this local user and their linked attendance/messages/excuses?'))return;db.users=db.users.filter(u=>u.id!==id);db.attendance=db.attendance.filter(a=>a.studentId!==id);db.excuses=db.excuses.filter(x=>x.studentId!==id);db.messages=db.messages.filter(m=>m.from!==id&&m.to!==id);save();adminPage();toast('User deleted.');}
function exportData(){const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`cstracker-backup-${today()}.json`;a.click();URL.revokeObjectURL(url);toast('Backup exported.');}
function importData(e){const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{try{const x=normalizeDb(JSON.parse(r.result));if(!Array.isArray(x.users)||!x.users.length)throw Error();if(!confirm('Importing will replace current local data. Continue?'))return;db=x;save();location.reload();}catch(_){toast('Invalid CSTracker backup file.');}};r.readAsText(file);e.target.value='';}
function resetData(){if(!isAdmin())return;if(!confirm('Reset all CSTracker local data to the built-in demo data?'))return;db=structuredClone(seed);save();location.reload();}

function render(p){
  currentPage=p; const pages={dashboard,schedule:schedulePage,calendar:calendarPage,announcements:announcementsPage,attendance:attendancePage,qr:qrPage,inbox:inboxPage,excuse:excusePage,admin:adminPage};
  (pages[p]||dashboard)(); applyTheme();
}

// Restore a session when possible.
try{
  const sid=sessionStorage.getItem('cstracker_session');
  if(sid){const u=db.users.find(x=>String(x.id)===sid);if(u){me=u;showApp();}}
}catch(_){ }

tick();
