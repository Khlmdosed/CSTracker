# CSTracker — Offline Demo

## Open it
1. Extract the ZIP.
2. Open `public/index.html` in a modern browser.
3. No Node.js, npm, server, internet connection, or CDN is required.

## Demo accounts
All demo accounts use password: `Demo1234!`

- Student: `student@cvsu.edu.ph`
- Professor: `professor`
- Class representative: `classrep`
- Moderator: `moderator`
- Administrator: `admin`

You can also use the demo buttons on the sign-in screen.

## Included
- CSTracker branding throughout the interface.
- Campus-email student login and staff username login.
- Student registration with Student ID, names, CvSU email, guardian Gmail, password, and regular/irregular selection.
- Irregular-student subject enrollment validation.
- Persistent local data using browser localStorage.
- Session restoration after refresh using sessionStorage.
- Schedule from the supplied class timetable, with professor, room, and subject information.
- Interactive calendar with event details and staff event management.
- Announcements with staff posting and deletion.
- Student attendance history and staff attendance verification.
- Duplicate attendance protection per student + subject + date.
- 3 lates = 1 effective absence within each subject.
- Warning levels based on effective absences.
- Excuse-letter submission and staff approval/rejection.
- Staff inbox and student message visibility.
- Student identity/QR-style card and staff verification workflow.
- Auto/Day/Night theme cycle, including the 5:00 AM–5:59 PM day and 6:00 PM–4:59 AM night rule.
- Responsive desktop/mobile layout.
- Admin-only user creation/edit/delete and local JSON backup/restore/reset.
- HTML escaping and defensive data normalization to reduce broken layouts from user-entered text.

## Important offline limitations
This is a static browser demo, not a secure multi-user production system. A static `file://` website cannot securely send CvSU confirmation email, send guardian email, synchronize a central database, or perform real camera QR decoding without additional bundled/server functionality.

The displayed student code is therefore explicitly labeled **QR-style** rather than being falsely presented as a standards-compliant scannable QR code. The staff workflow simulates the second verification step using the Student ID.

Passwords are stored locally for demo purposes. Do not use real passwords, real guardian addresses, or sensitive production data in this offline demo.
